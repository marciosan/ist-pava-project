public class TestD {
	public static void main(String[] args) {
		System.err.println(new VoidWidget());
	}
}
