public class TestH {
	public static void main(String[] args) {
		System.err.println(new FuncWidget());
	}
}
