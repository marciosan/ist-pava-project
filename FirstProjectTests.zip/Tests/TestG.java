public class TestG {
	public static void main(String[] args) {
		System.err.println(new Unknown());
	}
}
