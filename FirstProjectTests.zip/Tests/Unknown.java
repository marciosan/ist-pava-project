import ist.meic.pa.KeywordArgs;

public class Unknown {
	@KeywordArgs("")
	public Unknown(Object... args) {}
	
	public String toString() {
		return String.format("Nothing...");
	}
}
